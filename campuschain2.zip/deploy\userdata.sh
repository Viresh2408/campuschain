#!/bin/bash
# This runs automatically when the EC2 instance first boots
# It installs Docker, clones the repo, creates .env, builds and starts CampusChain

exec > /var/log/campuschain-setup.log 2>&1
set -e

echo "=== CampusChain Auto-Deploy Started at $(date) ==="

# 1. Update & Install Docker
dnf update -y
dnf install -y docker git

systemctl start docker
systemctl enable docker
usermod -aG docker ec2-user

# 2. Install Docker Compose v2
mkdir -p /usr/local/lib/docker/cli-plugins
curl -SL "https://github.com/docker/compose/releases/download/v2.24.0/docker-compose-linux-x86_64" \
  -o /usr/local/lib/docker/cli-plugins/docker-compose
chmod +x /usr/local/lib/docker/cli-plugins/docker-compose

echo "Docker version: $(docker --version)"
echo "Docker Compose version: $(docker compose version)"

# 3. Clone the project
cd /home/ec2-user
git clone https://github.com/Viresh2408/campuschain.git campuschain || {
  echo "Clone failed - repo may be private. Trying with token..."
  exit 1
}
cd campuschain

# 4. Write the .env file with all secrets
cat > .env << 'ENVEOF'
NEXT_PUBLIC_SUPABASE_URL=https://jcurfdnukfmnviwcjezh.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sb_publishable_OgzvNKHrCW1n8_4p5-0HCg_VZxdQSQT
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpjdXJmZG51a2ZtbnZpd2NqZXpoIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3NDc4ODQzMywiZXhwIjoyMDkwMzY0NDMzfQ.Z8TdemPpUdIKzDW51kXBNe4ExUizXuxI3dJoIn1iZ88
JWT_SECRET=campuschain_super_secret_jwt_key_2024_blockchain
NEXT_PUBLIC_EMAILJS_SERVICE_ID=service_k8eenqp
NEXT_PUBLIC_EMAILJS_TEMPLATE_ID=template_n623eoi
NEXT_PUBLIC_EMAILJS_PUBLIC_KEY=lpXslLy1OhX3eDXNR
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=ASIAQ4X7WZGCJB7OIQZN
AWS_SECRET_ACCESS_KEY=guSuwOhIZi67sJOYBXmiZGzcJr7L5H+9WKekUf1K
AWS_SESSION_TOKEN=IQoJb3JpZ2luX2VjEDQaCXVzLXdlc3QtMiJHMEUCIQCY1KawUjAz61Y9i2DQ9W6foCIhlS36zT02/uSl4dNQJAIgb+RELn0jkwQi24VJUO5c/pPta4LkXfHHbgNZKHYeMZcquAII/f//////////ARAAGgwwNjE3Mzk1NTExMDgiDEWps64D4iSj39RJeiqMAicmG/HpjjXKIT/crTDZSvTNfCVwwCNI//MiNcy/hf+mgtUFpj44VR9+xzXVWVpopjOEIAe1v7HB4ooCf+gHY1guQoP2zm/O7WmCzOOG4unmM8o9aH+ta7Lke9E8zvDJrAs7bD/3k3Cuj8K/1NOpqdpbXeKxQV/qOzVzp5fMPqgXknGb/b7aKBMvN+vY9iRyzUVSAxSY/32wcnE6v9eTw1u/wXpXH5942VoOGG1PNyf+IZdBOOTUVMwY3qt44f7//uBiuZdwxL2A+09BGyBZw/qW0sGeEFd1EaD58Y7zO7mwyug5yJzSdjPzAZg9TUJiXTbMN3sjMKOlHc9fWtG0bBgnnwEcJwQy/IBZ56gw+f7YzgY6nQFmi9XPpVIFCilUEkCa1A8/YBF/zZIx2TDLp6RSNJwSz5sOsxJAPpq1L8XIfdNuP/mljWAfF+8R9eJ/aXJGzrwk/3eqcDynmNv+0w5kpilgLHYa1C+5v2SsldAOMiCc9OGk7DOAybC2mC3lIiWyAATegey+6XtNWrcgST1KHHVeJdi3W14kOiCzjXih6D3bFgsbIEyZv1mQl3ckEztm
AWS_S3_BUCKET=campuschain-receipts-cc
AWS_SNS_FRAUD_TOPIC_ARN=arn:aws:sns:us-east-1:061739551108:CampusChain-FraudAlerts
AWS_DYNAMODB_TABLE=CampusChainFraudLogs
ENVEOF

chmod 600 .env
chown ec2-user:ec2-user .env
chown -R ec2-user:ec2-user /home/ec2-user/campuschain

# 5. Build and start with Docker Compose
docker compose --env-file .env build --no-cache
docker compose --env-file .env up -d

# 6. Verify it's running
sleep 10
if docker ps | grep -q campuschain-app; then
  echo "=== SUCCESS: CampusChain container is running! ==="
  PUBLIC_IP=$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)
  echo "=== App available at: http://${PUBLIC_IP}:3000 ==="
else
  echo "=== ERROR: Container failed to start. Check: docker compose logs ==="
  docker compose logs --tail=50
fi

echo "=== Setup completed at $(date) ==="
